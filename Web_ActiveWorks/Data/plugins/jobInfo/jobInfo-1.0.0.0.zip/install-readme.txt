﻿ActiveWorks plugin package

Plugin: Job Info
Version: 1.0.0.0

Application/* goes next to ActiveWorks.exe.
Profiles/_PROFILE_/Plugins/* goes to Profiles/<user profile>/Plugins.
